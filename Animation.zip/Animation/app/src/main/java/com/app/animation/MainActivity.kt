package com.app.animation

import android.animation.ObjectAnimator
import android.annotation.SuppressLint
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.graphics.PathParser


class MainActivity : AppCompatActivity() {
    @SuppressLint("Recycle")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val view: View = findViewById(R.id.view1)
        val animator = ObjectAnimator.ofFloat(view, "translationX","translationY",  PathParser.createPathFromPathData("M645.48,718.72L645.48,354.89c0,-12.25 -5.22,-23.14 -13.89,-32.67L321.37,12.2C317,7.84 320.09,0.61 328.32,0.61l121.16,0c8.71,0 17.29,3.41 23.79,9.91l266.9,266.77c8.66,8.66 13.51,20.44 13.51,32.7l0,452.86c0,12.23 -4.86,24.79 -13.51,33.44L474.04,1062.31C467.54,1068.81 458.73,1072.45 449.54,1072.45L327.09,1072.45c-6.17,0 -6.3,-7.46 -4.9,-11.83L631.62,751.62c8.65,-8.94 13.87,-20.67 13.87,-32.9z")).apply {
            duration = 8000
            start()
        }
    }
}